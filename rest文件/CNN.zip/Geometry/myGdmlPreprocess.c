//#include "/usr/local/REST/v2.2.0/packages/restG4/include/GdmlPreprocessor.hh"
//#include "myGdmlPreprocess.hh"
#include "myGdmlPreprocessor.h"
void myGdmlPreprocess(TString filename){
//(void myGdmlPreprocess(int argc,char **argv){
	system("cp " +filename + " " + filename + "_");
	GdmlPreprocessor* p = new GdmlPreprocessor();
	p->Load((string)(filename));
	//p->PrintContent();
}

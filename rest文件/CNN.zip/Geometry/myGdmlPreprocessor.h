
#ifndef restG4_GdmlPreprocessor
#define restG4_GdmlPreprocessor 

#include "TRestMetadata.h"

///////////////////////////////////////////
//we must preprocess gdml file because of a bug in TGDMLParse::Value() in ROOT6
//

class GdmlPreprocessor :public TRestMetadata {


public:
	string elementstr;
	bool isPreprocessed;
	void Load(string file) {
		isPreprocessed=false;
		if (fileExists(file)) {
			fConfigFileName = file;

			//getchar();

			std::ifstream t(file);
			std::string str((std::istreambuf_iterator<char>(t)),
				std::istreambuf_iterator<char>());
			elementstr = str;
			t.close();
			//int pos = str.find("<gdml", 0);
			int pos=0;
			cout<<pos<<endl;
			if (1) {
			//if (pos != -1) {
				string temp = str.substr(pos, -1);

				fElement = StringToElement(temp);
				fElementGlobal = GetElement("define", fElement);

				LoadSectionMetadata();

				ReplaceAttributeWithKeyWord("cos(");
				ReplaceAttributeWithKeyWord("sin(");
				ReplaceAttributeWithKeyWord("tan(");
				ReplaceAttributeWithKeyWord("sqrt(");
				ReplaceAttributeWithKeyWord("log(");
				ReplaceAttributeWithKeyWord("exp(");

				ofstream outf;
				outf.open(file, ios::trunc);
				outf << elementstr << endl;
				outf.close();
				//getchar();
			}		
			if(isPreprocessed) cout<<file<<" has been changed!"<<endl;	
		}
		else
		{
			error << "Filename : " << file << endl;
			error << "REST ERROR. File does not exist. Right path/filename?" << endl;
			exit(0);
		}
	}
	void InitFromConfigFile() {}

	void PrintContent() {

		cout << elementstr << endl;
	}

	void ReplaceAttributeWithKeyWord(string keyword) 
	{
		int n;
		//cout<<keyword<<endl;
		while ((n = elementstr.find(keyword, 0)) != -1)
		{
			isPreprocessed=true;
			int pos1 = 0, pos2 = 0;
			for (int i = n; i >= 0; i--) {
				if (elementstr[i] == '"') {
					pos1 = i + 1;
					break;
				}
			}

			for (unsigned int i = n; i < elementstr.size(); i++) {
				if (elementstr[i] == '"') {
					pos2 = i;
					break;
				}
			}

			string target = elementstr.substr(pos1, pos2 - pos1);
			//cout << target << endl;
			string replace = ReplaceMathematicalExpressions(ReplaceEnvironmentalVariables(target));
			//cout << replace << endl;
			elementstr.replace(pos1, pos2 - pos1, replace);

		}
	}


};

#endif

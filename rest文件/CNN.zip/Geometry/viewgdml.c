#include "TFile.h"
#include "TTree.h"
#include "TGraph.h"
#include "TCanvas.h"
#include "TString.h"
#include "TAxis.h"
#include "TGeoManager.h"
#include <iostream>

void viewgdml(const char* input){

	TFile *f = new TFile("test.root","recreate");
	TGeoManager *a = new TGeoManager("a", "Geometry");
	a->Import(input);
	a->Write();
	//f->Write();
	f->Close();

}
